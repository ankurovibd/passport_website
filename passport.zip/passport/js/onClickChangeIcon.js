function changeImage() {
    var image = document.getElementById('myImage');
    if (image.src.match("../images/Vector(9).png")) {
        image.src = "../images/angle-circle-down.png";
        document.getElementsByClassName("card").style.border = "solid #0000FF"; 
    } else {
        image.src = "../images/Vector(9).png";
    }
}